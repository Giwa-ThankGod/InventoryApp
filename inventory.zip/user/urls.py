from django.urls import path
from user import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('signin/', views.signin, name='signin'),

    path('dashboard/', views.dashboard, name='dashboard'),

    # Products
    path('add/inventory/', views.add_inventory, name='add-inventory'),
    path('view/inventory/', views.view_inventory, name='view-inventory'),
]